import St from 'gi://St';
import { BRIGHTNESS_VCP_CODE, CONTRAST_VCP_CODE, LOG_PREFIX } from './constants.js';
import * as Ddcutil from './ddcutil.js';
function createControl(vcpCode) {
    return { vcpCode, currentValue: 50, slider: null, valueLabel: null, sentValue: 50, inFlight: false, reading: false, updatingFromCode: false };
}
function createExtraDimming() {
    return { currentValue: 0, slider: null, valueLabel: null, overlay: null, updatingFromCode: false };
}
export class DisplayController {
    _settings;
    _displays = [];
    _detectComplete = false;
    _disposed = false;
    onDetectComplete = null;
    constructor(settings) {
        this._settings = settings;
    }
    get displays() { return this._displays; }
    get detectComplete() { return this._detectComplete; }
    reset() {
        this._destroyOverlays();
        this._displays = [];
        this._detectComplete = false;
    }
    cleanup() {
        this._disposed = true;
        this._destroyOverlays();
    }
    detect() {
        Ddcutil.detectDisplays(parsed => {
            if (this._disposed)
                return;
            this._displays = parsed.map(p => ({
                bus: p.bus, name: p.name, connector: p.connector, monitorIndex: -1,
                brightness: createControl(BRIGHTNESS_VCP_CODE),
                contrast: createControl(CONTRAST_VCP_CODE),
                extraDimming: createExtraDimming(),
            }));
            this._detectComplete = true;
            console.debug(`${LOG_PREFIX} Found ${this._displays.length} displays`);
            this._mapMonitorsToDisplays();
            this.onDetectComplete?.();
            for (const display of this._displays) {
                this.readControl(display, 'brightness');
                this.readControl(display, 'contrast');
            }
        });
    }
    _mapMonitorsToDisplays() {
        const manager = global.backend.get_monitor_manager();
        for (const display of this._displays) {
            if (!display.connector)
                continue;
            const index = manager.get_monitor_for_connector(display.connector);
            if (index >= 0)
                display.monitorIndex = index;
        }
    }
    _control(display, kind) { return display[kind]; }
    _targets(display) {
        return this._settings.get_boolean('link-displays') ? this._displays : [display];
    }
    getActiveDisplay() {
        if (this._settings.get_boolean('link-displays'))
            return this._displays[0] ?? null;
        const focused = global.display.focus_window?.get_monitor() ?? global.display.get_primary_monitor();
        return this._displays.find(display => display.monitorIndex === focused) ?? this._displays[0] ?? null;
    }
    // Keyboard shortcuts remain brightness-only. Contrast is adjusted from its slider.
    adjustBrightnessDelta(delta) {
        const display = this.getActiveDisplay();
        if (display)
            this.setControlValue(display, 'brightness', display.brightness.currentValue + delta * this._settings.get_int('step'));
    }
    setFromSlider(display, kind, percent) {
        this.setControlValue(display, kind, percent);
    }
    setControlValue(display, kind, rawValue) {
        const value = Math.max(0, Math.min(100, rawValue));
        for (const target of this._targets(display)) {
            const control = this._control(target, kind);
            control.currentValue = value;
            this._updateControlUi(control, value);
            this._requestSend(target, control);
        }
    }
    /**
     * Dims the rendered image for one display only. This is intentionally not
     * tied to "Link displays" and never sends a DDC command to the monitor.
     */
    setExtraDimming(display, rawValue) {
        const value = Math.max(0, Math.min(100, rawValue));
        const dimming = display.extraDimming;
        dimming.currentValue = value;
        dimming.updatingFromCode = true;
        if (dimming.slider)
            dimming.slider.value = value / 100;
        dimming.valueLabel?.set_text(`${value}%`);
        dimming.updatingFromCode = false;
        this._updateDimmingOverlay(display);
    }
    _updateControlUi(control, value) {
        control.updatingFromCode = true;
        if (control.slider)
            control.slider.value = value / 100;
        control.valueLabel?.set_text(`${value}%`);
        control.updatingFromCode = false;
    }
    _requestSend(display, control) {
        if (this._disposed || control.inFlight || control.currentValue === control.sentValue)
            return;
        const value = control.currentValue;
        control.sentValue = value;
        control.inFlight = true;
        Ddcutil.setBrightness(display.bus, control.vcpCode, value, () => {
            control.inFlight = false;
            this._requestSend(display, control);
        });
    }
    readControl(display, kind) {
        const control = this._control(display, kind);
        if (control.reading)
            return;
        control.reading = true;
        Ddcutil.readBrightness(display.bus, control.vcpCode, value => {
            control.reading = false;
            if (this._disposed || value === null)
                return;
            control.sentValue = value;
            control.currentValue = value;
            this._updateControlUi(control, value);
        });
    }
    _updateDimmingOverlay(display) {
        const dimming = display.extraDimming;
        if (dimming.currentValue === 0) {
            dimming.overlay?.hide();
            return;
        }
        if (!dimming.overlay) {
            dimming.overlay = new St.Widget({
                reactive: false,
                visible: false,
            });
            global.stage.add_child(dimming.overlay);
        }
        const monitor = display.monitorIndex >= 0
            ? display.monitorIndex
            : global.display.get_primary_monitor();
        const geometry = global.display.get_monitor_geometry(monitor);
        dimming.overlay.set_position(geometry.x, geometry.y);
        dimming.overlay.set_size(geometry.width, geometry.height);
        dimming.overlay.set_style(`background-color: rgba(0, 0, 0, ${dimming.currentValue / 100});`);
        dimming.overlay.show();
    }
    _destroyOverlays() {
        for (const display of this._displays) {
            display.extraDimming.overlay?.destroy();
            display.extraDimming.overlay = null;
        }
    }
}
