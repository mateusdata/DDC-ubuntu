import { BRIGHTNESS_VCP_CODE, CONTRAST_VCP_CODE, LOG_PREFIX } from './constants.js';
import * as Ddcutil from './ddcutil.js';
function createControl(vcpCode) {
    return { vcpCode, currentValue: 50, slider: null, valueLabel: null, sentValue: 50, inFlight: false, reading: false, updatingFromCode: false };
}
export class DisplayController {
    _settings;
    _displays = [];
    _detectComplete = false;
    _disposed = false;
    onDetectComplete = null;
    constructor(settings) {
        this._settings = settings;
    }
    get displays() { return this._displays; }
    get detectComplete() { return this._detectComplete; }
    reset() {
        this._displays = [];
        this._detectComplete = false;
    }
    cleanup() { this._disposed = true; }
    detect() {
        Ddcutil.detectDisplays(parsed => {
            if (this._disposed)
                return;
            this._displays = parsed.map(p => ({
                bus: p.bus, name: p.name, connector: p.connector, monitorIndex: -1,
                brightness: createControl(BRIGHTNESS_VCP_CODE),
                contrast: createControl(CONTRAST_VCP_CODE),
            }));
            this._detectComplete = true;
            console.debug(`${LOG_PREFIX} Found ${this._displays.length} displays`);
            this._mapMonitorsToDisplays();
            this.onDetectComplete?.();
            for (const display of this._displays) {
                this.readControl(display, 'brightness');
                this.readControl(display, 'contrast');
            }
        });
    }
    _mapMonitorsToDisplays() {
        const manager = global.backend.get_monitor_manager();
        for (const display of this._displays) {
            if (!display.connector)
                continue;
            const index = manager.get_monitor_for_connector(display.connector);
            if (index >= 0)
                display.monitorIndex = index;
        }
    }
    _control(display, kind) { return display[kind]; }
    _targets(display) {
        return this._settings.get_boolean('link-displays') ? this._displays : [display];
    }
    getActiveDisplay() {
        if (this._settings.get_boolean('link-displays'))
            return this._displays[0] ?? null;
        const focused = global.display.focus_window?.get_monitor() ?? global.display.get_primary_monitor();
        return this._displays.find(display => display.monitorIndex === focused) ?? this._displays[0] ?? null;
    }
    // Keyboard shortcuts remain brightness-only. Contrast is adjusted from its slider.
    adjustBrightnessDelta(delta) {
        const display = this.getActiveDisplay();
        if (display)
            this.setControlValue(display, 'brightness', display.brightness.currentValue + delta * this._settings.get_int('step'));
    }
    setFromSlider(display, kind, percent) {
        this.setControlValue(display, kind, percent);
    }
    setControlValue(display, kind, rawValue) {
        const value = Math.max(0, Math.min(100, rawValue));
        for (const target of this._targets(display)) {
            const control = this._control(target, kind);
            control.currentValue = value;
            this._updateControlUi(control, value);
            this._requestSend(target, control);
        }
    }
    _updateControlUi(control, value) {
        control.updatingFromCode = true;
        if (control.slider)
            control.slider.value = value / 100;
        control.valueLabel?.set_text(`${value}%`);
        control.updatingFromCode = false;
    }
    _requestSend(display, control) {
        if (this._disposed || control.inFlight || control.currentValue === control.sentValue)
            return;
        const value = control.currentValue;
        control.sentValue = value;
        control.inFlight = true;
        Ddcutil.setBrightness(display.bus, control.vcpCode, value, () => {
            control.inFlight = false;
            this._requestSend(display, control);
        });
    }
    readControl(display, kind) {
        const control = this._control(display, kind);
        if (control.reading)
            return;
        control.reading = true;
        Ddcutil.readBrightness(display.bus, control.vcpCode, value => {
            control.reading = false;
            if (this._disposed || value === null)
                return;
            control.sentValue = value;
            control.currentValue = value;
            this._updateControlUi(control, value);
        });
    }
}
